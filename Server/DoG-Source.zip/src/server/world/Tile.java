package server.world;

public class Tile {

	public int x, y, height;

	public Tile(int x, int y, int h) {
		this.x = x;
		this.y = y;
		this.height = h;
	}

}
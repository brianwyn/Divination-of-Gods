package server.world.clip.region;

public class Region2 {

	public static void load() {
		Region.load();
	}

}
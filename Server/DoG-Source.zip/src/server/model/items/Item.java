package server.model.items;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import server.Config;
import server.Server;

public class Item {

	private static String[] fullbody = { "top", "chestplate", "shirt",
			"platebody", "Ahrims robetop", "Karils leathertop", "brassard",
			"Robe top", "robetop", "platebody (t)", "platebody (g)",
			"chestplate", "robe", "torso", "hauberk", "Dragon chainbody",
			"blouse", "jacket" };

	private static String[] fullhat = { "med helm", "coif", "Dharok's helm",
			"Slayer helmet", "hood", "Initiate helm", "Coif",
			"Helm of neitiznot", "Armadyl helmet", "Berserker helm",
			"Archer helm", "Farseer helm", "Warrior helm", "Void",
			"Lumberjack hat", "Reindeer hat", "Larupia hat", "mask",
			"Kyatt hat", "Bomber cap", "Dwarven helmet", "Pernix mask",
			"Pernix cowl" };

	private static String[] fullmask = { "full helm", "Afro", "afro", "mask",
			"Verac's helm", "Guthan's helm", "Karil's coif", "mask",
			"Torag's helm", "sallet", "Saradomin helm", "Lunar helm",
			"Pernix mask", "Pernix cowl" };

	public static boolean[] itemStackable = new boolean[Config.ITEM_LIMIT];

	public static boolean[] itemIsNote = new boolean[Config.ITEM_LIMIT];

	public static final int[] targetSlots = new int[Config.ITEM_LIMIT];

	static {
		int counter = 0;
		int c;

		try {
			FileInputStream dataIn = new FileInputStream(new File(
					Config.DATA_PATH + "/items/stackable.dat"));
			while ((c = dataIn.read()) != -1) {
				if (c == 0) {
					itemStackable[counter] = false;
					itemStackable[counter] = false;
					itemStackable[19152] = true;
					itemStackable[19157] = true;
					itemStackable[19162] = true;

					itemStackable[16427] = true; // morrigan throwing axe
					itemStackable[16432] = true; // morrigan throwing axe
					itemStackable[13879] = true; // morrigan javelin
					itemStackable[13879] = true; // morrigan javelin
					itemStackable[18201] = true; // morrigan javelin
					itemStackable[13957] = true; // morrigan javelin
					itemStackable[18016] = true;
					itemStackable[12158] = true;
					itemStackable[12159] = true;
					itemStackable[12160] = true;
					itemStackable[12163] = true;
					itemStackable[12155] = true;
					itemStackable[15243] = true;
					itemStackable[16462] = true;// fog tokens
					itemStackable[4820] = true;// fog tokens
					itemStackable[1539] = true;// fog tokens
					itemStackable[15273] = true;// rocktail

				} else {
					itemStackable[counter] = true;
				}
				counter++;
			}
			dataIn.close();
		} catch (IOException e) {
			System.out
					.println("Critical error while loading stackabledata! Trace:");
			e.printStackTrace();
		}
		itemStackable[16427] = true;// fog tokens
		itemStackable[16462] = true;// fog tokens
		itemStackable[16432] = true;// fog tokens
		itemStackable[12852] = true;// fog tokens
		itemStackable[12851] = true;// runes
		itemStackable[12850] = true;// runes
		itemStackable[15262] = true;// shardpack
		itemStackable[7684] = true;// death touch darts
		itemStackable[12437] = true;// Wolpertin summonin scroll
		itemStackable[12825] = true;// steel titan summonin scroll
		itemStackable[12833] = true;// geyser titan scroll
		itemStackable[12824] = true;// most titan scroll
		itemStackable[12827] = true;// abbysal titan scroll
		itemStackable[12435] = true;// pak yack scroll 12435
		itemStackable[12434] = true;// unicorn stallion scroll
		itemStackable[12438] = true;// bunyip scrolls
		itemStackable[12437] = true;// Wolperting's scroll
		itemStackable[15273] = true;// rocktail

		counter = 0;

		try {
			FileInputStream dataIn = new FileInputStream(new File(
					Config.DATA_PATH + "/items/notes.dat"));
			while ((c = dataIn.read()) != -1) {
				if (c == 0) {
					itemIsNote[counter] = true;
				} else {
					itemIsNote[counter] = false;
				}
				counter++;
			}
			dataIn.close();
		} catch (IOException e) {
			System.out.println("Critical error while loading notedata! Trace:");
			e.printStackTrace();
		}

		counter = 0;
		try {
			FileInputStream dataIn = new FileInputStream(new File(
					Config.DATA_PATH + "/items/equipment.dat"));
			while ((c = dataIn.read()) != -1) {
				targetSlots[counter++] = c;
			}
			dataIn.close();
		} catch (IOException e) {
			System.out.println("Critical error while loading notedata! Trace:");
			e.printStackTrace();
		}
	}

	public static Object forId(int itemId) {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getItemName(int id) {
		for (int j = 0; j < Server.itemHandler.ItemList.length; j++) {
			if (Server.itemHandler.ItemList[j] != null)
				if (Server.itemHandler.ItemList[j].itemId == id)
					return Server.itemHandler.ItemList[j].itemName;
		}
		return null;
	}

	public static boolean isFullBody(int itemId) {
		String weapon = getItemName(itemId);
		if (weapon == null)
			return false;
		for (int i = 0; i < fullbody.length; i++) {
			if (weapon.endsWith(fullbody[i]) || weapon.contains(fullbody[i])) {
				return true;
			}
		}
		return false;
	}

	public static boolean isFullHelm(int itemId) {
		String weapon = getItemName(itemId);
		if (weapon == null)
			return false;
		for (int i = 0; i < fullhat.length; i++) {
			if (weapon.endsWith(fullhat[i]) && itemId != 2631
					&& itemId != 11277 && itemId != 11278) {
				return true;
			}
		}
		return false;
	}

	public static boolean isFullMask(int itemId) {
		String weapon = getItemName(itemId);
		if (weapon == null)
			return false;
		for (int i = 0; i < fullmask.length; i++) {
			if (weapon.endsWith(fullmask[i]) && itemId != 2631
					&& itemId != 9925 && itemId != 10728 && itemId != 11277
					&& itemId != 11278) {
				return true;
			}
		}
		return false;
	}

	public static boolean playerAmulet(int itemId) {
		String[] data = { "amulet", "Amulet", "scarf", "Necklace", "necklace",
				"Pendant", "pendant", "Symbol", "symbol", "stole", "Stole" };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerArrows(int itemId) {
		String[] data = { "Arrows", "arrows", "Arrow", "arrow", "Bolts",
				"bolts", "Shot", "shot", "rack", "Rack", };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerBody(int itemId) {
		String[] data = { "body", "top", "Priest gown", "apron", "shirt",
				"platebody", "robetop", "body(g)", "body(t)",
				"Wizard robe (g)", "Wizard robe (t)", "body", "brassard",
				"blouse", "tunic", "leathertop", "Saradomin plate",
				"chainbody", "hauberk", "Shirt", "torso", "chestplate",
				"jacket", };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerBoots(int itemId) {
		String[] data = { "Shoes", "shoes", "boots", "Boots", "Flippers",
				"flippers" };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerCape(int itemId) {
		String[] data = { "cloak", "cape", "Cape", "attractor", "Attractor",
				"Ava's" };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerGloves(int itemId) {
		String[] data = { "Gloves", "gloves", "glove", "Glove", "Vamb", "vamb",
				"gauntlets", "Gauntlets", "bracers", "Bracers", "Vambraces",
				"vambraces" };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerHats(int itemId) {
		String[] data = { "boater", "cowl", "head", "peg", "coif", "helm",
				"Coif", "mask", "hat", "headband", "hood", "disguise",
				"cavalier", "full", "tiara", "helmet", "Hat", "ears", "crown",
				"partyhat", "helm(t)", "helm(g)", "beret", "facemask",
				"sallet", "hat(g)", "hat(t)", "bandana", "Helm", "Mitre",
				"mitre", "Bomber cap", };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerLegs(int itemId) {
		String[] data = { "tassets", "chaps", "bottoms", "gown", "trousers",
				"platelegs", "robe", "plateskirt", "legs", "leggings",
				"shorts", "Skirt", "skirt", "cuisse", "Trousers", "Pantaloons", };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if ((item.endsWith(data[i]) || item.contains(data[i]))
					&& (!item.contains("top") && (!item.contains("robe (g)") && (!item
							.contains("robe (t)"))))) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerRings(int itemId) {
		String[] data = { "ring", "rings", "Ring", "Rings", };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}

	public static boolean playerShield(int itemId) {
		String[] data = { "kiteshield", "book", "Kiteshield", "toktz-ket-xil",
				"Toktz-ket-xil", "shield", "Shield", "Kite", "kite",
				"Defender", "defender", "Tome" };
		String item = getItemName(itemId);
		if (item == null) {
			return false;
		}
		boolean item1 = false;
		for (int i = 0; i < data.length; i++) {
			if (item.endsWith(data[i]) || item.contains(data[i])) {
				item1 = true;
			}
		}
		return item1;
	}
}
package server.model.items;

public class Name {
	public int itemId;
	public String itemName;
	public String itemNamez;

	public Name(int _itemId) {
		itemId = _itemId;
	}
}
